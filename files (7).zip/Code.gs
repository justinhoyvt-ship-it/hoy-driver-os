// Pulse Core OS — Code.gs
// Entry points, dashboard state, shift workflow, settings, and shared helpers.

function pulseHealthCheck() {
  return {
    ok: true,
    project: 'Pulse Core OS',
    spreadsheetId: HDO.SPREADSHEET_ID,
    time: new Date().toISOString()
  };
}

function doGet(e) {
  if (e && e.parameter && e.parameter.code) {
    return handleUberOAuthCallback_(e.parameter.code);
  }
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Pulse Core OS')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover');
}

function getAppState() {
  const ss = SpreadsheetApp.openById(HDO.SPREADSHEET_ID);
  const dash = ss.getSheetByName(HDO.SHEETS.DASHBOARD);
  return {
    generatedAt: Utilities.formatDate(new Date(), HDO.TZ, 'EEE MMM d, h:mm a'),
    kpis: {
      dailyGoal: moneyNumber_(dash.getRange('B3').getValue()),
      todayGross: moneyNumber_(dash.getRange('B4').getValue()),
      todayNet: moneyNumber_(dash.getRange('B5').getValue()),
      onlineHours: numberOrZero_(dash.getRange('B6').getValue()),
      netPerHour: numberOrZero_(dash.getRange('B7').getValue()),
      weeklyNet: moneyNumber_(dash.getRange('B8').getValue()),
      weeklyGoal: moneyNumber_(dash.getRange('B9').getValue()),
      weeklyProgress: numberOrZero_(dash.getRange('B10').getValue()),
      pointsToPlatinum: numberOrZero_(dash.getRange('B11').getValue())
    },
    decision: dash.getRange('B12').getDisplayValue() || 'NO SHIFT DATA',
    acceptanceMode: dash.getRange('B23').getDisplayValue() || 'PROTECT - default accept',
    optimizationRule: dash.getRange('B24').getDisplayValue() || '',
    morningPlan: getShiftPlanForUi_(8),
    baseline: {
      operatingEarnings: dash.getRange('B18').getDisplayValue(), rides: dash.getRange('B19').getDisplayValue(),
      medianGrossHour: dash.getRange('B20').getDisplayValue(), backtest: dash.getRange('B21').getDisplayValue(),
      liveTest: dash.getRange('B22').getDisplayValue()
    },
    recommendation: getCurrentRecommendation_(),
    activeShift: getActiveShift_(),
    recentShifts: getRecentShifts_(8),
    topZones: getTopZoneForecasts_(8),
    tests: getTests_(6),
    settings: getSettingsObject_(),
    uberApi: getUberDriverApiStatus(),
    signalsApi: getUberSignalsStatus(),
    dataHealth: getDataHealth_(),
    automation: getPulseTriggerStatus()
  };
}

function startShift(payload) {
  const props = PropertiesService.getUserProperties();
  if (props.getProperty('ACTIVE_SHIFT')) throw new Error('A shift is already active.');
  props.setProperty('ACTIVE_SHIFT', JSON.stringify({
    startedAt: new Date().toISOString(), zone: (payload && payload.zone) || 'South Burlington hotels',
    gross: 0, tips: 0, promo: 0, miles: 0, activeHours: 0, notes: ''
  }));
  return getAppState();
}

function updateShiftCheckpoint(payload) {
  const props = PropertiesService.getUserProperties();
  const raw = props.getProperty('ACTIVE_SHIFT');
  if (!raw) throw new Error('No active shift found.');
  const active = JSON.parse(raw);
  ['gross','tips','promo','miles','activeHours'].forEach(k => {
    if (payload[k] !== undefined) active[k] = numberOrZero_(payload[k]);
  });
  if (payload.zone) active.zone = payload.zone;
  if (payload.notes !== undefined) active.notes = String(payload.notes || '');
  props.setProperty('ACTIVE_SHIFT', JSON.stringify(active));
  return getAppState();
}

function endShift(payload) {
  const props = PropertiesService.getUserProperties();
  const raw = props.getProperty('ACTIVE_SHIFT');
  if (!raw) throw new Error('No active shift found.');
  const active = JSON.parse(raw);
  const started = new Date(active.startedAt), ended = new Date();
  const onlineHours = Math.max(0.01, (ended.getTime() - started.getTime()) / 3600000);
  const gross = payload && payload.gross !== undefined ? numberOrZero_(payload.gross) : numberOrZero_(active.gross);
  const tips = payload && payload.tips !== undefined ? numberOrZero_(payload.tips) : numberOrZero_(active.tips);
  const promo = payload && payload.promo !== undefined ? numberOrZero_(payload.promo) : numberOrZero_(active.promo);
  const miles = payload && payload.miles !== undefined ? numberOrZero_(payload.miles) : numberOrZero_(active.miles);
  const zone = (payload && payload.zone) || active.zone || 'Other';
  const queue = (payload && payload.airportQueue) || 'Skipped';
  const weather = (payload && payload.weather) || 'Clear';
  const notes = (payload && payload.notes) || active.notes || '';
  const activeHours = payload && payload.activeHours !== undefined ? numberOrZero_(payload.activeHours) : numberOrZero_(active.activeHours);

  const ss = SpreadsheetApp.openById(HDO.SPREADSHEET_ID);
  const sh = ss.getSheetByName(HDO.SHEETS.SHIFT_LOG);
  const row = nextEmptyRow_(sh, 2, 200, 1);
  sh.getRange(row, 1, 1, 10).setValues([[
    new Date(Utilities.formatDate(started, HDO.TZ, 'yyyy/MM/dd')), Utilities.formatDate(started, HDO.TZ, 'EEE'),
    started, ended, round_(onlineHours, 2), activeHours || '', gross, tips, promo, miles
  ]]);
  sh.getRange(row, 16, 1, 4).setValues([[zone, queue, weather, notes]]);
  props.deleteProperty('ACTIVE_SHIFT');
  SpreadsheetApp.flush();
  return {savedRow: row, dashboard: getAppState()};
}

function cancelActiveShift() {
  PropertiesService.getUserProperties().deleteProperty('ACTIVE_SHIFT');
  return getAppState();
}

function getActiveShift_() {
  const raw = PropertiesService.getUserProperties().getProperty('ACTIVE_SHIFT');
  if (!raw) return null;
  const a = JSON.parse(raw), started = new Date(a.startedAt), now = new Date();
  a.elapsedHours = round_((now.getTime() - started.getTime()) / 3600000, 2);
  a.startedLabel = Utilities.formatDate(started, HDO.TZ, 'h:mm a');
  a.grossPerHour = a.elapsedHours > 0 ? round_(numberOrZero_(a.gross) / a.elapsedHours, 2) : 0;
  a.liveDecision = !a.gross ? 'LOG EARNINGS' : a.grossPerHour >= 45 ? 'KEEP DRIVING' : a.grossPerHour >= 34 ? 'WATCH NEXT BLOCK' : 'REPOSITION / END';
  return a;
}

function getRecentShifts_(limit) {
  const sh = SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.SHIFT_LOG);
  const rows = sh.getRange(2, 1, Math.max(1, sh.getLastRow() - 1), 20).getDisplayValues().filter(r => r[0]).slice(-limit).reverse();
  return rows.map(r => ({date:r[0], onlineHours:r[4], gross:r[6], tips:r[7], miles:r[9], net:r[13], netPerHour:r[14], zone:r[15], decision:r[19]}));
}

function getTests_(limit) {
  const sh = SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.TESTS);
  const rows = sh.getRange(2, 1, Math.min(limit, Math.max(1, sh.getLastRow() - 1)), 16).getDisplayValues();
  return rows.filter(r => r[0]).map(r => ({id:r[0], date:r[1], status:r[2], hypothesis:r[3], baseline:r[4], green:r[5], red:r[6], result:r[15]}));
}

function getSettingsObject_() {
  const sh = SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.SETTINGS);
  const map = {};
  sh.getRange('A2:B24').getValues().forEach(r => { if (r[0]) map[String(r[0])] = r[1]; });
  return {
    fuelPerGallon:numberOrZero_(map['Fuel $/gallon']), mpg:numberOrZero_(map['MPG']), maintenancePerMile:numberOrZero_(map['Maintenance $/mile']),
    taxRate:numberOrZero_(map['Tax set-aside %']), dailyGoal:numberOrZero_(map['Daily Goal']), weeklyGoal:numberOrZero_(map['Weekly Goal']),
    targetNetHour:numberOrZero_(map['Target Net $/hr']), baseLocation:String(map['Base Location'] || 'Essex, VT'),
    pointsToPlatinum:numberOrZero_(map['Uber Tier Points']), quickCashGoal:numberOrZero_(map['Quick Cash Goal']), goalDays:numberOrZero_(map['Goal Days']),
    acceptanceStrategy:String(map['Acceptance Strategy'] || 'PROTECT'), acceptanceGuardrail:numberOrZero_(map['Acceptance Guardrail']), defaultRideAction:String(map['Default Ride Action'] || 'ACCEPT'),
    dailyWindowStart:String(map['Daily Window Start'] || '06:30'), dailyWindowHours:numberOrZero_(map['Daily Window Hours']) || 4,
    plannerSwitchDelta:numberOrZero_(map['Planner Switch Delta']) || 0.5, plannerMinDwellMin:numberOrZero_(map['Planner Min Dwell Min']) || 45,
    eventPrebufferMin:numberOrZero_(map['Event Prebuffer Min']) || 90, eventPostbufferMin:numberOrZero_(map['Event Postbuffer Min']) || 45
  };
}

function saveSettings(settings) {
  const sh = SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.SETTINGS);
  const updates = {'Fuel $/gallon':settings.fuelPerGallon,'MPG':settings.mpg,'Maintenance $/mile':settings.maintenancePerMile,'Tax set-aside %':settings.taxRate,'Daily Goal':settings.dailyGoal,'Weekly Goal':settings.weeklyGoal,'Target Net $/hr':settings.targetNetHour,'Uber Tier Points':settings.pointsToPlatinum,'Quick Cash Goal':settings.quickCashGoal,'Goal Days':settings.goalDays,'Acceptance Guardrail':settings.acceptanceGuardrail,'Planner Switch Delta':settings.plannerSwitchDelta,'Planner Min Dwell Min':settings.plannerMinDwellMin,'Event Prebuffer Min':settings.eventPrebufferMin,'Event Postbuffer Min':settings.eventPostbufferMin};
  sh.getRange('A2:A24').getValues().flat().forEach((label,i) => { if (Object.prototype.hasOwnProperty.call(updates,label)) sh.getRange(i+2,2).setValue(numberOrZero_(updates[label])); });
  SpreadsheetApp.flush();
  return getAppState();
}

function getCurrentRecommendation_() {
  const ss = SpreadsheetApp.openById(HDO.SPREADSHEET_ID), sh = ss.getSheetByName(HDO.SHEETS.PLAN);
  if (sh && sh.getLastRow() > 1) {
    const rows = sh.getRange(2,1,sh.getLastRow()-1,8).getValues(), now = new Date();
    let upcoming = null;
    for (const r of rows) {
      const start = r[0] instanceof Date ? r[0] : new Date(r[0]), end = r[1] instanceof Date ? r[1] : new Date(r[1]);
      if (start <= now && end >= now) return {zone:r[2], score:r[3], confidence:r[4], why:r[5], action:r[6], nextCheck:formatDateTime_(r[7]), mode:'NOW'};
      if (!upcoming && start > now) upcoming = r;
    }
    if (upcoming) return {zone:upcoming[2], score:upcoming[3], confidence:upcoming[4], why:upcoming[5], action:upcoming[6], nextCheck:formatDateTime_(upcoming[7]), mode:'NEXT SHIFT'};
  }
  return {zone:'South Burlington hotels / BTV feeder corridor', score:null, confidence:'Baseline', why:'Morning hotel departures and airport feeder opportunity.', action:'Default accept. Avoid dead airport queue time.', nextCheck:'After first ride sequence', mode:'FALLBACK'};
}

function getTopZoneForecasts_(limit) {
  const sh = SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.SIGNALS);
  if (!sh || sh.getLastRow() < 2) return [];
  const rows=sh.getRange(2,1,sh.getLastRow()-1,11).getDisplayValues(), out=[], seen=new Set();
  for(const r of rows){
    const key=r[0];
    if(!key||seen.has(key))continue;
    seen.add(key);
    out.push({time:r[0],zone:r[1],flight:r[2],event:r[3],weather:r[4],personal:r[5],timePrior:r[6],penalty:r[7],score:r[8],confidence:r[9],reason:r[10]});
    if(out.length>=limit)break;
  }
  return out;
}

function getShiftPlanForUi_(limit) {
  const sh=SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.PLAN);
  if(!sh||sh.getLastRow()<2)return[];
  return sh.getRange(2,1,Math.min(limit,sh.getLastRow()-1),8).getDisplayValues()
    .filter(r=>r[0]&&r[2])
    .map(r=>[r[0]+' – '+r[1],r[2]+' · '+r[4]+' · '+r[6]]);
}



function getDataHealth_() {
  const ss=SpreadsheetApp.openById(HDO.SPREADSHEET_ID),
    weather=ss.getSheetByName(HDO.SHEETS.RAW_WEATHER),
    flights=ss.getSheetByName(HDO.SHEETS.RAW_FLIGHTS),
    events=ss.getSheetByName(HDO.SHEETS.RAW_EVENTS),
    signals=ss.getSheetByName(HDO.SHEETS.SIGNALS),
    plan=ss.getSheetByName(HDO.SHEETS.PLAN);
  const weatherCoverageEnd=maxDateInColumn_(weather,2),
    signalStart=minDateInColumn_(signals,1),
    signalEnd=maxDateInColumn_(signals,1),
    covers=Boolean(weatherCoverageEnd&&signalStart&&weatherCoverageEnd.getTime()>=signalStart.getTime());
  return {
    weatherCoverageEnd: formatFullDateTime_(weatherCoverageEnd),
    weatherCoversPlanStart: covers,
    flightRows: flights?Math.max(0,flights.getLastRow()-1):0,
    eventRows: events?Math.max(0,events.getLastRow()-1):0,
    signalRows: signals?Math.max(0,signals.getLastRow()-1):0,
    planSegments: plan?Math.max(0,plan.getLastRow()-1):0,
    signalStart: formatFullDateTime_(signalStart),
    signalEnd: signalEnd?formatFullDateTime_(new Date(signalEnd.getTime()+15*60000)):''
  };
}

function maxDateInColumn_(sh,column) {
  if(!sh||sh.getLastRow()<2)return null;
  let best=null;
  sh.getRange(2,column,sh.getLastRow()-1,1).getValues().flat().forEach(v=>{if(v instanceof Date&&(!best||v>best))best=v;});
  return best;
}

function minDateInColumn_(sh,column) {
  if(!sh||sh.getLastRow()<2)return null;
  let best=null;
  sh.getRange(2,column,sh.getLastRow()-1,1).getValues().flat().forEach(v=>{if(v instanceof Date&&(!best||v<best))best=v;});
  return best;
}

function formatFullDateTime_(v){if(!v)return '';const d=v instanceof Date?v:new Date(v);return Utilities.formatDate(d,HDO.TZ,'M/d h:mm a');}

function getPulseTriggerStatus() {
  const handlers=ScriptApp.getProjectTriggers().map(t=>t.getHandlerFunction());
  return {
    refreshPredictiveData: handlers.filter(h=>h==='refreshPredictiveData').length,
    syncUberDriverData: handlers.filter(h=>h==='syncUberDriverData').length,
    total: handlers.length
  };
}

function refreshPulseDataNow() {
  const refresh=refreshPredictiveData();
  return {refresh:refresh,state:getAppState()};
}

function installPulseAutomation() {
  createOrResetTriggers_();
  const refresh=refreshPredictiveData();
  return {triggers:getPulseTriggerStatus(),refresh:refresh,state:getAppState()};
}

function checkUberSignalsStatus() {
  return getUberSignalsStatus();
}

function runUberSignalsTokenTest() {
  const result=testUberSignalsToken();
  console.log(JSON.stringify(result));
  return result;
}

function runUberBearerConnectivityTest() {
  const result=testUberBearerConnectivity();
  console.log(JSON.stringify(result));
  return result;
}

function setupHoyDriverOS() { ensurePipelineSheets_(); createOrResetTriggers_(); refreshPredictiveData(); return getAppState(); }
function createOrResetTriggers_() {
  ScriptApp.getProjectTriggers().forEach(t => { if (['refreshPredictiveData','syncUberDriverData'].indexOf(t.getHandlerFunction()) >= 0) ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('refreshPredictiveData').timeBased().everyHours(1).create();
  if (getUberDriverApiStatus().configured) ScriptApp.newTrigger('syncUberDriverData').timeBased().everyHours(1).create();
}
function nextEmptyRow_(sheet,startRow,maxRow,column){const vals=sheet.getRange(startRow,column,maxRow-startRow+1,1).getValues();for(let i=0;i<vals.length;i++){if(!vals[i][0])return startRow+i;}throw new Error('Shift Log is full. Add more rows before saving.');}
function numberOrZero_(v){const n=Number(v);return Number.isFinite(n)?n:0;}
function moneyNumber_(v){return round_(numberOrZero_(v),2);}
function round_(n,p){const f=Math.pow(10,p||0);return Math.round((Number(n)+Number.EPSILON)*f)/f;}
function formatDateTime_(v){if(!v)return '';const d=v instanceof Date?v:new Date(v);return Utilities.formatDate(d,HDO.TZ,'h:mm a');}
