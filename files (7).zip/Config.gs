// Pulse Core OS — Config.gs
// Non-secret configuration only. Secrets belong in Apps Script Script Properties.

const HDO = {
  SPREADSHEET_ID: '13m_9QDnIgXSdMBdtSYMjmyIdo55wh8F5Fl3_1JaYl-w',
  TZ: 'America/New_York',
  SHEETS: {
    DASHBOARD: 'Dashboard', SHIFT_LOG: 'Shift Log', SETTINGS: 'Settings', EVENTS: 'Event Radar',
    ZONES: 'Zone Scorecard', TESTS: 'Test Runs', RAW_FLIGHTS: 'RAW_FLIGHTS',
    RAW_WEATHER: 'RAW_WEATHER', RAW_EVENTS: 'RAW_EVENTS', SIGNALS: 'SIGNALS_15M',
    PLAN: 'SHIFT_PLAN', UBER_TRIPS: 'RAW_UBER_TRIPS', UBER_PAYMENTS: 'RAW_UBER_PAYMENTS', RAW_UBER_SIGNALS: 'RAW_UBER_SIGNALS'
  }
};
