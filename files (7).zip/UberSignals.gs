// Pulse Core OS — UberSignals.gs
// Marketplace Signals client-credentials lane. No secrets or tokens are returned to the UI,
// written to Sheets, or committed to source control.

function getUberSignalsStatus() {
  const p = PropertiesService.getScriptProperties();
  const expiresAt = numberOrZero_(p.getProperty('UBER_SIGNALS_TOKEN_EXPIRES_AT'));
  return {
    configured: Boolean(
      p.getProperty('UBER_SIGNALS_CLIENT_ID') &&
      p.getProperty('UBER_SIGNALS_CLIENT_SECRET')
    ),
    hasCachedToken: Boolean(
      p.getProperty('UBER_SIGNALS_ACCESS_TOKEN') &&
      (!expiresAt || Date.now() < expiresAt)
    ),
    tokenExpiresAt: expiresAt || null,
    sandboxUrlConfigured: Boolean(p.getProperty('UBER_SIGNALS_SANDBOX_URL')),
    scope: p.getProperty('UBER_SIGNALS_SCOPE') || '3p.signals.eta',
    tokenUrlConfigured: Boolean(p.getProperty('UBER_SIGNALS_TOKEN_URL')),
    lastTokenSuccessAt: p.getProperty('UBER_SIGNALS_LAST_TOKEN_SUCCESS_AT') || null
  };
}

function getUberSignalsAccessToken_() {
  const p = PropertiesService.getScriptProperties();
  const clientId = p.getProperty('UBER_SIGNALS_CLIENT_ID');
  const clientSecret = p.getProperty('UBER_SIGNALS_CLIENT_SECRET');
  if (!clientId || !clientSecret) {
    throw new Error('Missing Uber Signals credentials in Script Properties.');
  }

  const expiresAt = numberOrZero_(p.getProperty('UBER_SIGNALS_TOKEN_EXPIRES_AT'));
  const cached = p.getProperty('UBER_SIGNALS_ACCESS_TOKEN');
  if (cached && (!expiresAt || Date.now() < expiresAt - 5 * 60000)) return cached;

  const scope = p.getProperty('UBER_SIGNALS_SCOPE') || '3p.signals.eta';
  const tokenUrl = p.getProperty('UBER_SIGNALS_TOKEN_URL') ||
    'https://sandbox-login.uber.com/oauth/v2/token';

  const response = UrlFetchApp.fetch(tokenUrl, {
    method: 'post',
    contentType: 'application/x-www-form-urlencoded',
    payload: {
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: 'client_credentials',
      scope: scope
    },
    muteHttpExceptions: true
  });

  const status = response.getResponseCode();
  let body = {};
  try { body = JSON.parse(response.getContentText() || '{}'); } catch (ignore) {}

  if (status < 200 || status >= 300 || !body.access_token) {
    const safeCode = body.error || body.code || 'token_exchange_failed';
    const safeMessage = body.error_description || body.message || ('HTTP ' + status);
    throw new Error('Uber Signals token request failed: ' + safeCode + ' — ' + safeMessage);
  }

  const expiresIn = numberOrZero_(body.expires_in);
  p.setProperty('UBER_SIGNALS_ACCESS_TOKEN', String(body.access_token));
  p.setProperty('UBER_SIGNALS_TOKEN_EXPIRES_AT', String(Date.now() + expiresIn * 1000));
  if (body.scope) p.setProperty('UBER_SIGNALS_RETURNED_SCOPE', String(body.scope));
  p.setProperty('UBER_SIGNALS_LAST_TOKEN_SUCCESS_AT', new Date().toISOString());
  return String(body.access_token);
}

function testUberSignalsToken() {
  const p = PropertiesService.getScriptProperties();
  const diag = {
    success: false,
    stage: 'token_exchange',
    credentialsFound: Boolean(
      p.getProperty('UBER_SIGNALS_CLIENT_ID') &&
      p.getProperty('UBER_SIGNALS_CLIENT_SECRET')
    ),
    scope: p.getProperty('UBER_SIGNALS_SCOPE') || '3p.signals.eta',
    tokenUrlSet: Boolean(p.getProperty('UBER_SIGNALS_TOKEN_URL')),
    tokenStoredServerSide: false,
    expiresAt: null,
    error: null
  };
  try {
    const token = getUberSignalsAccessToken_();
    diag.success = Boolean(token);
    diag.tokenStoredServerSide = Boolean(token);
    diag.expiresAt = p.getProperty('UBER_SIGNALS_TOKEN_EXPIRES_AT') || null;
    diag.returnedScope = p.getProperty('UBER_SIGNALS_RETURNED_SCOPE') || '';
  } catch (err) {
    diag.error = String(err && err.message ? err.message : err);
  }
  return diag;
}

// Safe bearer-token connectivity test based on the exact Products example shared from the
// Uber integration steps. This does NOT become a Marketplace Signals data source.
function testUberBearerConnectivity() {
  const url = 'https://test-api.uber.com/v1.2/products?latitude=37.7759792&longitude=-122.41823';
  const token = getUberSignalsAccessToken_();
  const response = UrlFetchApp.fetch(url, {
    method: 'get',
    headers: { Authorization: 'Bearer ' + token },
    muteHttpExceptions: true
  });
  const status = response.getResponseCode();
  let body = {};
  try { body = JSON.parse(response.getContentText() || '{}'); } catch (ignore) {}
  const products = Array.isArray(body.products) ? body.products : [];
  const errorMessage=body.error_description || body.message || null;
  const scopeIsolationConfirmed=status===401 && String(errorMessage||'').indexOf('ride_request.estimate')>=0;
  return {
    success: status >= 200 && status < 300,
    stage: 'bearer_connectivity',
    httpStatus: status,
    productCount: products.length,
    productNames: products.slice(0, 12).map(function(p) { return p.display_name || p.product_id || 'product'; }),
    errorCode: body.error || body.code || null,
    errorMessage: errorMessage,
    scopeIsolationConfirmed: scopeIsolationConfirmed,
    note: scopeIsolationConfirmed ?
      'Expected scope isolation: Products requires ride_request.estimate and is not the Marketplace Signals lane.' :
      'Diagnostic example only. Products API output is not used as Marketplace Signals input.'
  };
}

function testUberSignalsSandbox() {
  const p = PropertiesService.getScriptProperties();
  const url = p.getProperty('UBER_SIGNALS_SANDBOX_URL');
  if (!url) {
    return {
      success: false,
      blocked: true,
      stage: 'marketplace_signals_request',
      error: 'UBER_SIGNALS_SANDBOX_URL is not set. Use only the exact Marketplace Signals endpoint from Uber documentation/dashboard.'
    };
  }
  return fetchUberSignalsJson_(url);
}

function fetchUberSignalsJson_(url) {
  const token = getUberSignalsAccessToken_();
  const response = UrlFetchApp.fetch(url, {
    method: 'get',
    headers: { Authorization: 'Bearer ' + token },
    muteHttpExceptions: true
  });
  const status = response.getResponseCode();
  const bodyText = response.getContentText() || '';
  let parsed = null;
  try { parsed = JSON.parse(bodyText); } catch (ignore) {}
  return {
    success: status >= 200 && status < 300,
    stage: 'marketplace_signals_request',
    httpStatus: status,
    data: status >= 200 && status < 300 ? (parsed || { raw: bodyText.slice(0, 10000) }) : null,
    errorCode: parsed && (parsed.error || parsed.code) || null,
    errorMessage: parsed && (parsed.error_description || parsed.message) || (status >= 300 ? ('HTTP ' + status) : null)
  };
}

function ingestUberSignalsSandbox() {
  const result = testUberSignalsSandbox();
  if (!result.success) return result;
  const ss = SpreadsheetApp.openById(HDO.SPREADSHEET_ID);
  const sh = ensureSheet_(ss, HDO.SHEETS.RAW_UBER_SIGNALS,
    ['Fetched At', 'Source', 'HTTP Status', 'Payload JSON']);
  const payload = JSON.stringify(result.data || {});
  sh.appendRow([new Date(), 'UBER_MARKETPLACE_SIGNALS', result.httpStatus, payload.slice(0, 49000)]);
  return {
    success: true,
    stage: 'marketplace_signals_ingest',
    httpStatus: result.httpStatus,
    writtenSheet: HDO.SHEETS.RAW_UBER_SIGNALS,
    payloadCharactersStored: Math.min(payload.length, 49000),
    mappingStatus: 'RAW_ONLY_PENDING_CONFIRMED_SCHEMA'
  };
}

function clearUberSignalsTokenCache() {
  const p = PropertiesService.getScriptProperties();
  p.deleteProperty('UBER_SIGNALS_ACCESS_TOKEN');
  p.deleteProperty('UBER_SIGNALS_TOKEN_EXPIRES_AT');
  p.deleteProperty('UBER_SIGNALS_RETURNED_SCOPE');
  return getUberSignalsStatus();
}
