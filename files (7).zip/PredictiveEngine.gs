// Pulse Core OS — PredictiveEngine.gs
// Deterministic flight/weather/event/personal-history scoring and four-hour route planning.

const ZONE_DEFS = [
  {name:'BTV Airport',key:'BTV',flightWeight:1.00,eventWeight:0.10,weatherWeight:0.45,timeBias:{5:70,6:75,7:65,8:50,16:55,17:60,18:65,19:60}},
  {name:'South Burlington hotels',key:'SBHOTELS',flightWeight:0.75,eventWeight:0.45,weatherWeight:0.50,timeBias:{5:70,6:80,7:78,8:68,9:55,16:50,17:55,18:60}},
  {name:'Church Street / Downtown',key:'DOWNTOWN',flightWeight:0.15,eventWeight:1.00,weatherWeight:0.90,timeBias:{7:35,8:45,9:50,11:55,12:65,16:65,17:75,18:80,19:85,20:90,21:90,22:85,23:80}},
  {name:'UVM',key:'UVM',flightWeight:0.10,eventWeight:0.65,weatherWeight:0.80,timeBias:{7:60,8:75,9:65,10:55,14:55,15:65,16:70,17:65}},
  {name:'Winooski',key:'WINOOSKI',flightWeight:0.10,eventWeight:0.45,weatherWeight:0.70,timeBias:{7:45,8:50,11:45,12:50,17:65,18:75,19:80,20:75,21:70}},
  {name:'Essex Junction',key:'ESSEX',flightWeight:0.05,eventWeight:0.80,weatherWeight:0.45,timeBias:{6:50,7:55,8:50,16:55,17:60,18:65}},
  {name:'Waterfront',key:'WATERFRONT',flightWeight:0.05,eventWeight:1.00,weatherWeight:0.75,timeBias:{17:55,18:65,19:75,20:85,21:90,22:80}}
];

function ensurePipelineSheets_() {
  const ss = SpreadsheetApp.openById(HDO.SPREADSHEET_ID);
  ensureSheet_(ss,HDO.SHEETS.RAW_FLIGHTS,['Fetched At','Flight','Airline','Origin','Scheduled Arrival','Estimated Arrival','Actual Arrival','Status','Delay Min','Terminal','Gate','Dedup Key']);
  ensureSheet_(ss,HDO.SHEETS.RAW_WEATHER,['Fetched At','Forecast Time','Temperature F','Precipitation','Rain','Snowfall','Visibility','Wind Gust MPH','Weather Shock Score']);
  ensureSheet_(ss,HDO.SHEETS.RAW_EVENTS,['Fetched At','Event Date','Event','Location','Expected Demand','Driver Window','Driver Move']);
  ensureSheet_(ss,HDO.SHEETS.SIGNALS,['Time','Zone','Flight Signal','Event Signal','Weather Signal','Personal Signal','Time Prior','Penalty','Score','Confidence','Reason']);
  ensureSheet_(ss,HDO.SHEETS.PLAN,['Start','End','Zone','Score','Confidence','Why','Action','Next Check']);
  ensureSheet_(ss,HDO.SHEETS.UBER_TRIPS,['Synced At','Trip ID','Pickup Time','Dropoff Time','Fare','Distance Miles','Duration Sec','Surge Multiplier','Start City','Status']);
  ensureSheet_(ss,HDO.SHEETS.UBER_PAYMENTS,['Synced At','Payment ID','Event Time','Category','Amount','Currency','Trip ID','Toll','Service Fee','Other']);
}

function refreshPredictiveData() {
  ensurePipelineSheets_();
  const results = {
    flights:safeRun_('flights',fetchBtvFlights_),
    weather:safeRun_('weather',fetchBurlingtonWeather_),
    events:safeRun_('events',syncEventRadar_),
    scoring:null
  };
  results.scoring = rebuildSignalsAndPlan_();
  return results;
}

function fetchBtvFlights_() {
  const props=PropertiesService.getScriptProperties(), key=props.getProperty('AVIATIONSTACK_API_KEY');
  if(!key)return{skipped:true,reason:'AVIATIONSTACK_API_KEY not set'};
  const base=props.getProperty('AVIATIONSTACK_BASE_URL')||'https://api.aviationstack.com/v1/flights';
  const url=base+'?access_key='+encodeURIComponent(key)+'&arr_iata=BTV&limit=100';
  const response=UrlFetchApp.fetch(url,{muteHttpExceptions:true});
  if(response.getResponseCode()>=300)throw new Error('AviationStack HTTP '+response.getResponseCode()+': '+response.getContentText().slice(0,300));
  const body=JSON.parse(response.getContentText()), flights=body.data||[];
  const sh=SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.RAW_FLIGHTS);
  const existing=new Set(sh.getLastRow()>1?sh.getRange(2,12,sh.getLastRow()-1,1).getDisplayValues().flat().filter(Boolean):[]);
  const now=new Date(), rows=[];
  flights.forEach(f=>{
    const arr=f.arrival||{}, dep=f.departure||{}, flight=(f.flight&&f.flight.iata)||(f.flight&&f.flight.number)||'', airline=(f.airline&&f.airline.name)||'', scheduled=arr.scheduled||'', dedup=[flight,scheduled].join('|');
    if(!flight||existing.has(dedup))return;
    rows.push([now,flight,airline,dep.iata||'',scheduled?new Date(scheduled):'',arr.estimated?new Date(arr.estimated):'',arr.actual?new Date(arr.actual):'',f.flight_status||'',numberOrZero_(arr.delay),arr.terminal||'',arr.gate||'',dedup]);
  });
  if(rows.length)sh.getRange(sh.getLastRow()+1,1,rows.length,rows[0].length).setValues(rows);
  return{received:flights.length,appended:rows.length};
}

function fetchBurlingtonWeather_() {
  const url='https://api.open-meteo.com/v1/forecast?latitude=44.4759&longitude=-73.2121&minutely_15=temperature_2m,precipitation,rain,snowfall,visibility,wind_gusts_10m&temperature_unit=fahrenheit&wind_speed_unit=mph&timezone=America%2FNew_York&forecast_minutely_15=96';
  const response=UrlFetchApp.fetch(url,{muteHttpExceptions:true});
  if(response.getResponseCode()>=300)throw new Error('Open-Meteo HTTP '+response.getResponseCode());
  const body=JSON.parse(response.getContentText()), m=body.minutely_15||{}, times=m.time||[], rows=[], fetched=new Date();
  for(let i=0;i<times.length;i++){
    const precip=numberOrZero_(m.precipitation&&m.precipitation[i]), rain=numberOrZero_(m.rain&&m.rain[i]), snow=numberOrZero_(m.snowfall&&m.snowfall[i]), gust=numberOrZero_(m.wind_gusts_10m&&m.wind_gusts_10m[i]), prev=i>0?numberOrZero_(m.precipitation[i-1]):0;
    let shock=0;if(prev===0&&precip>0)shock+=55;shock+=Math.min(25,precip*20);shock+=Math.min(20,snow*30);shock+=gust>=25?10:0;shock=Math.min(100,shock);
    rows.push([fetched,new Date(times[i]),numberOrZero_(m.temperature_2m&&m.temperature_2m[i]),precip,rain,snow,numberOrZero_(m.visibility&&m.visibility[i]),gust,shock]);
  }
  const sh=SpreadsheetApp.openById(HDO.SPREADSHEET_ID).getSheetByName(HDO.SHEETS.RAW_WEATHER);
  if(sh.getLastRow()>1)sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).clearContent();
  if(rows.length)sh.getRange(2,1,rows.length,rows[0].length).setValues(rows);
  return{appended:rows.length};
}

function syncEventRadar_() {
  const ss=SpreadsheetApp.openById(HDO.SPREADSHEET_ID), source=ss.getSheetByName(HDO.SHEETS.EVENTS), target=ss.getSheetByName(HDO.SHEETS.RAW_EVENTS);
  if(!source||source.getLastRow()<2)return{appended:0};
  const rows=source.getRange(2,1,source.getLastRow()-1,6).getValues().filter(r=>r[0]&&r[1]).map(r=>[new Date(),r[0],r[1],r[2],r[3],r[4],r[5]]);
  if(target.getLastRow()>1)target.getRange(2,1,target.getLastRow()-1,target.getLastColumn()).clearContent();
  if(rows.length)target.getRange(2,1,rows.length,rows[0].length).setValues(rows);
  return{appended:rows.length};
}

function rebuildSignalsAndPlan_() {
  const ss=SpreadsheetApp.openById(HDO.SPREADSHEET_ID), signalSheet=ss.getSheetByName(HDO.SHEETS.SIGNALS), planSheet=ss.getSheetByName(HDO.SHEETS.PLAN);
  const window=getNextShiftWindow_(), start=window.start, horizon=window.end;
  const weatherRows=readRows_(ss.getSheetByName(HDO.SHEETS.RAW_WEATHER),2,9), flightRows=readRows_(ss.getSheetByName(HDO.SHEETS.RAW_FLIGHTS),2,12), eventRows=readRows_(ss.getSheetByName(HDO.SHEETS.RAW_EVENTS),2,7), personalMap=getPersonalZonePerformance_(), settings=getSettingsObject_();
  const signalRows=[], topByTime=[];
  for(let t=new Date(start);t<horizon;t=new Date(t.getTime()+15*60000)){
    const zoneScores=ZONE_DEFS.map(z=>scoreZone_(z,t,flightRows,eventRows,weatherRows,personalMap,settings)).sort((a,b)=>b.score-a.score);
    topByTime.push({time:new Date(t),best:zoneScores[0],scores:zoneScores});
    zoneScores.forEach(s=>signalRows.push([new Date(t),s.zone,s.flight,s.event,s.weather,s.personal,s.timePrior,s.penalty,s.score,s.confidence,s.reason]));
  }
  if(signalSheet.getLastRow()>1)signalSheet.getRange(2,1,signalSheet.getLastRow()-1,signalSheet.getLastColumn()).clearContent();
  if(signalRows.length)signalSheet.getRange(2,1,signalRows.length,signalRows[0].length).setValues(signalRows);
  const planRows=compressPlan_(topByTime);
  if(planSheet.getLastRow()>1)planSheet.getRange(2,1,planSheet.getLastRow()-1,planSheet.getLastColumn()).clearContent();
  if(planRows.length)planSheet.getRange(2,1,planRows.length,planRows[0].length).setValues(planRows);
  SpreadsheetApp.flush();return{signals:signalRows.length,planSegments:planRows.length};
}

function scoreZone_(zone,time,flights,events,weather,personalMap,settings){
  const flight=flightSignal_(zone,time,flights),
    event=eventSignal_(zone,time,events,settings),
    weatherScore=weatherSignal_(zone,time,weather),
    hasPersonal=personalMap[zone.name]!==undefined,
    personal=hasPersonal?personalMap[zone.name]:50,
    hour=time.getHours(),
    timePrior=zone.timeBias[hour]!==undefined?zone.timeBias[hour]:40,
    penalty=zone.key==='BTV'?12:(zone.key==='ESSEX'?8:5);
  const raw=0.25*flight+0.20*event+0.15*weatherScore+0.20*personal+0.10*timePrior+0.10*Math.max(flight,event)-penalty,
    score=Math.max(0,Math.min(100,round_(raw,1))),
    sourceCount=(flight>=25?1:0)+(event>=25?1:0)+(weatherScore>=20?1:0)+(hasPersonal?1:0),
    confidence=sourceCount>=2&&score>=45?'HIGH':(sourceCount>=1||score>=30?'MEDIUM':'LOW');
  const reasons=[];
  if(flight>=55)reasons.push('arrival cluster');
  if(event>=55)reasons.push('event demand window');
  if(weatherScore>=45)reasons.push('weather shock');
  if(hasPersonal&&personal>=65)reasons.push('your history');
  if(!reasons.length)reasons.push('time-of-day prior');
  return{zone:zone.name,flight:round_(flight,1),event:round_(event,1),weather:round_(weatherScore,1),personal:round_(personal,1),timePrior:round_(timePrior,1),penalty:penalty,score:score,confidence:confidence,reason:reasons.join(' + ')};
}

function flightSignal_(zone,time,rows){let cluster=0;rows.forEach(r=>{const candidate=r[5]||r[4];if(!(candidate instanceof Date))return;const delta=Math.abs(candidate.getTime()-time.getTime())/60000;if(delta<=45){const proximity=Math.max(0,100-(delta/45)*70),delayBoost=Math.min(20,numberOrZero_(r[8])/3);cluster+=proximity+delayBoost;}});return Math.min(100,cluster/2.2)*zone.flightWeight;}

function eventSignal_(zone,time,rows,settings){
  let best=0;
  rows.forEach(r=>{
    const eventDate=r[1];
    if(!(eventDate instanceof Date))return;
    const factor=eventWindowFactor_(eventDate,r[5],time,settings);
    if(factor<=0)return;
    const demand=String(r[4]||'').toLowerCase(),
      base=demand.indexOf('very high')>=0?95:demand.indexOf('high')>=0?80:demand.indexOf('medium')>=0?55:35,
      loc=String(r[3]||'').toLowerCase();
    let locationMatch=false;
    if(zone.key==='DOWNTOWN'&&(loc.indexOf('flynn')>=0||loc.indexOf('burlington')>=0))locationMatch=true;
    if(zone.key==='WATERFRONT'&&loc.indexOf('waterfront')>=0)locationMatch=true;
    if(zone.key==='ESSEX'&&loc.indexOf('essex')>=0)locationMatch=true;
    if(zone.key==='SBHOTELS'&&(loc.indexOf('higher ground')>=0||loc.indexOf('south burlington')>=0))locationMatch=true;
    if(locationMatch)best=Math.max(best,base*factor);
  });
  return best*zone.eventWeight;
}

function eventWindowFactor_(eventDate,windowText,time,settings){
  const parsed=parseDriverWindow_(eventDate,windowText);
  if(!parsed)return 0;
  const pre=Math.max(0,numberOrZero_(settings.eventPrebufferMin)||90),
    post=Math.max(0,numberOrZero_(settings.eventPostbufferMin)||45),
    t=time.getTime(), start=parsed.start.getTime(), end=parsed.end.getTime(),
    preStart=start-pre*60000, postEnd=end+post*60000;
  if(t<preStart||t>postEnd)return 0;
  if(t>=start&&t<=end)return 1;
  if(t<start){
    if(pre===0)return 0;
    const mins=(start-t)/60000;
    return Math.max(0.35,1-(mins/pre)*0.65);
  }
  if(post===0)return 0;
  const mins=(t-end)/60000;
  return Math.max(0.25,1-(mins/post)*0.75);
}

function parseDriverWindow_(eventDate,windowText){
  const cleaned=String(windowText||'').replace(/\best\.?/ig,'').trim();
  const m=cleaned.match(/(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?\s*[-–—]\s*(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?/i);
  if(!m)return null;
  const startMer=(m[3]||m[6]||'').toUpperCase(), endMer=(m[6]||m[3]||'').toUpperCase();
  if(!startMer||!endMer)return null;
  const start=clockOnDate_(eventDate,Number(m[1]),Number(m[2]||0),startMer),
    end=clockOnDate_(eventDate,Number(m[4]),Number(m[5]||0),endMer);
  if(end.getTime()<=start.getTime())end.setDate(end.getDate()+1);
  return{start:start,end:end};
}

function clockOnDate_(baseDate,hour,minute,meridiem){
  let h=hour%12;
  if(String(meridiem).toUpperCase()==='PM')h+=12;
  return new Date(baseDate.getFullYear(),baseDate.getMonth(),baseDate.getDate(),h,minute,0,0);
}

function weatherSignal_(zone,time,rows){let closest=null,deltaBest=Infinity;rows.forEach(r=>{const ft=r[1];if(!(ft instanceof Date))return;const d=Math.abs(ft.getTime()-time.getTime());if(d<deltaBest){deltaBest=d;closest=r;}});return closest?numberOrZero_(closest[8])*zone.weatherWeight:0;}

function getPersonalZonePerformance_(){const ss=SpreadsheetApp.openById(HDO.SPREADSHEET_ID),sh=ss.getSheetByName(HDO.SHEETS.ZONES),out={};if(!sh||sh.getLastRow()<2)return out;const target=getSettingsObject_().targetNetHour||30;sh.getRange(2,1,sh.getLastRow()-1,10).getValues().forEach(r=>{const zone=String(r[0]||''),avg=numberOrZero_(r[7]);if(zone&&avg)out[zone]=Math.max(0,Math.min(100,(avg/target)*70));});return out;}

function compressPlan_(topByTime){
  if(!topByTime.length)return[];
  const settings=getSettingsObject_(),
    switchDelta=Math.max(0,numberOrZero_(settings.plannerSwitchDelta)||0.5),
    minDwell=Math.max(15,numberOrZero_(settings.plannerMinDwellMin)||45),
    segments=[];
  let activeZone=topByTime[0].best.zone,
    current={start:topByTime[0].time,end:new Date(topByTime[0].time.getTime()+15*60000),best:topByTime[0].best};
  for(let i=1;i<topByTime.length;i++){
    const item=topByTime[i],
      activeScore=item.scores.find(s=>s.zone===activeZone)||item.best,
      candidate=item.best,
      dwellMin=(item.time.getTime()-current.start.getTime())/60000,
      shouldSwitch=candidate.zone!==activeZone&&dwellMin>=minDwell&&(candidate.score-activeScore.score)>=switchDelta;
    if(shouldSwitch){
      segments.push(current);
      activeZone=candidate.zone;
      current={start:item.time,end:new Date(item.time.getTime()+15*60000),best:candidate};
    }else{
      current.end=new Date(item.time.getTime()+15*60000);
      if(activeScore.score>current.best.score)current.best=activeScore;
    }
  }
  segments.push(current);
  return segments.map(s=>[s.start,s.end,s.best.zone,s.best.score,s.best.confidence,s.best.reason,actionForZone_(s.best.zone,s.best.score),s.end]);
}

function actionForZone_(zone,score){
  let move='Default accept and follow profitable ride flow.';
  if(zone==='BTV Airport')move='Approach through hotel feeder corridor; avoid dead queue time.';
  else if(zone==='South Burlington hotels')move='Stage in hotel / Williston Road corridor and let paid rides move you.';
  else if(zone==='Church Street / Downtown')move='Circle edge streets; avoid curbside dead waiting.';
  else if(zone==='UVM')move='Work dense campus / medical corridor; stack short profitable rides.';
  else if(zone==='Winooski')move='Use as bridge zone between Burlington and Essex.';
  else if(zone==='Essex Junction')move='Use as launch point; avoid getting stranded outside the core.';
  else if(zone==='Waterfront')move='Stage outside event traffic gridlock before exit window.';
  if(score<30)return move+' Baseline confidence: recheck after the first ride sequence.';
  if(score<45)return move+' Recheck within 30 minutes or after two rides.';
  return move;
}

function getNextShiftWindow_(){
  const settings=getSettingsObject_(), parts=String(settings.dailyWindowStart||'06:30').split(':'), hour=Number(parts[0]||6), minute=Number(parts[1]||30), hours=numberOrZero_(settings.dailyWindowHours)||4, now=new Date();
  let start=new Date(now.getFullYear(),now.getMonth(),now.getDate(),hour,minute,0,0), end=new Date(start.getTime()+hours*3600000);
  if(now>end){start=new Date(start.getTime()+24*3600000);end=new Date(start.getTime()+hours*3600000);}
  return{start:floorTo15_(start),end:end};
}

function floorTo15_(date){const d=new Date(date);d.setSeconds(0,0);d.setMinutes(Math.floor(d.getMinutes()/15)*15);return d;}
function readRows_(sh,startRow,cols){if(!sh||sh.getLastRow()<startRow)return[];return sh.getRange(startRow,1,sh.getLastRow()-startRow+1,cols).getValues();}
function ensureSheet_(ss,name,headers){let sh=ss.getSheetByName(name);if(!sh)sh=ss.insertSheet(name);if(sh.getLastRow()===0||!sh.getRange(1,1).getValue()){sh.getRange(1,1,1,headers.length).setValues([headers]);sh.setFrozenRows(1);}return sh;}
function safeRun_(name,fn){try{return fn();}catch(err){console.error(name+': '+err.stack);return{error:String(err.message||err)};}}
