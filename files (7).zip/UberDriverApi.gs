// Pulse Core OS — UberDriverApi.gs
// Separate future user-authorized Driver API lane. Not used by Marketplace Signals.

function getUberDriverApiStatus() {
  const p = PropertiesService.getScriptProperties();
  const clientId = p.getProperty('UBER_CLIENT_ID');
  const clientSecret = p.getProperty('UBER_CLIENT_SECRET');
  const refreshToken = p.getProperty('UBER_REFRESH_TOKEN');
  const accessToken = p.getProperty('UBER_ACCESS_TOKEN');
  return {
    limitedAccessRequired: true,
    configured: Boolean(clientId && clientSecret && (refreshToken || accessToken)),
    hasClientId: Boolean(clientId),
    hasRefreshToken: Boolean(refreshToken),
    scopes: ['partner.accounts','partner.payments','partner.trips']
  };
}

function getUberAuthorizationUrl() {
  const p = PropertiesService.getScriptProperties();
  const clientId = p.getProperty('UBER_CLIENT_ID');
  const redirectUri = p.getProperty('UBER_REDIRECT_URI');
  if (!clientId || !redirectUri) throw new Error('Set UBER_CLIENT_ID and UBER_REDIRECT_URI in Script Properties first.');
  const scopes = 'partner.accounts partner.payments partner.trips';
  return 'https://auth.uber.com/oauth/v2/authorize?client_id=' + encodeURIComponent(clientId)
    + '&response_type=code&redirect_uri=' + encodeURIComponent(redirectUri)
    + '&scope=' + encodeURIComponent(scopes) + '&state=pulse-core-os';
}

function handleUberOAuthCallback_(code) {
  try {
    exchangeUberAuthorizationCode_(code);
    return HtmlService.createHtmlOutput('<meta name="viewport" content="width=device-width,initial-scale=1"><div style="font:16px system-ui;padding:24px;max-width:520px;margin:auto"><h2>Uber connection saved</h2><p>Pulse Core OS can now sync approved Driver API data.</p><p>You can close this tab and reopen the dashboard.</p></div>');
  } catch (err) {
    return HtmlService.createHtmlOutput('<meta name="viewport" content="width=device-width,initial-scale=1"><div style="font:16px system-ui;padding:24px"><h2>Connection error</h2><pre>' + escapeHtml_(String(err.message || err)) + '</pre></div>');
  }
}

function exchangeUberAuthorizationCode_(code) {
  const p = PropertiesService.getScriptProperties();
  const response = UrlFetchApp.fetch('https://auth.uber.com/oauth/v2/token', {
    method:'post',
    payload:{client_secret:p.getProperty('UBER_CLIENT_SECRET'),client_id:p.getProperty('UBER_CLIENT_ID'),grant_type:'authorization_code',redirect_uri:p.getProperty('UBER_REDIRECT_URI'),code:code},
    muteHttpExceptions:true
  });
  if(response.getResponseCode()>=300)throw new Error('Uber token exchange failed: '+response.getContentText());
  const token=JSON.parse(response.getContentText());
  p.setProperty('UBER_ACCESS_TOKEN',token.access_token);
  if(token.refresh_token)p.setProperty('UBER_REFRESH_TOKEN',token.refresh_token);
  p.setProperty('UBER_TOKEN_EXPIRES_AT',String(Date.now()+numberOrZero_(token.expires_in)*1000));
  return token;
}

function refreshUberAccessToken_() {
  const p=PropertiesService.getScriptProperties(), refreshToken=p.getProperty('UBER_REFRESH_TOKEN');
  if(!refreshToken)throw new Error('No UBER_REFRESH_TOKEN is stored.');
  const response=UrlFetchApp.fetch('https://auth.uber.com/oauth/v2/token',{method:'post',payload:{client_secret:p.getProperty('UBER_CLIENT_SECRET'),client_id:p.getProperty('UBER_CLIENT_ID'),grant_type:'refresh_token',refresh_token:refreshToken},muteHttpExceptions:true});
  if(response.getResponseCode()>=300)throw new Error('Uber refresh failed: '+response.getContentText());
  const token=JSON.parse(response.getContentText());
  p.setProperty('UBER_ACCESS_TOKEN',token.access_token);if(token.refresh_token)p.setProperty('UBER_REFRESH_TOKEN',token.refresh_token);p.setProperty('UBER_TOKEN_EXPIRES_AT',String(Date.now()+numberOrZero_(token.expires_in)*1000));return token.access_token;
}

function getUberAccessToken_() {
  const p=PropertiesService.getScriptProperties(), expiresAt=numberOrZero_(p.getProperty('UBER_TOKEN_EXPIRES_AT'));let token=p.getProperty('UBER_ACCESS_TOKEN');
  if(!token||(expiresAt&&Date.now()>expiresAt-3600000))token=refreshUberAccessToken_();
  return token;
}

function syncUberDriverData() {
  ensurePipelineSheets_();
  const status=getUberDriverApiStatus();
  if(!status.configured)return{skipped:true,reason:'Uber Driver API not configured or access not approved'};
  const to=Math.floor(Date.now()/1000), from=to-(3*24*3600);
  return{trips:syncUberTrips_(from,to),payments:syncUberPayments_(from,to)};
}

function syncUberTrips_(fromTime,toTime) {
  const token=getUberAccessToken_(), url='https://api.uber.com/v1/partners/trips?limit=50&from_time='+fromTime+'&to_time='+toTime, body=uberGetJson_(url,token);
  const rows=(body.trips||[]).map(t=>[new Date(),t.trip_id||'',t.pickup&&t.pickup.timestamp?new Date(t.pickup.timestamp*1000):'',t.dropoff&&t.dropoff.timestamp?new Date(t.dropoff.timestamp*1000):'',numberOrZero_(t.fare),numberOrZero_(t.distance),numberOrZero_(t.duration),numberOrZero_(t.surge_multiplier),t.start_city&&t.start_city.display_name?t.start_city.display_name:'',t.status||'']);
  return appendDedupedRows_(HDO.SHEETS.UBER_TRIPS,rows,2);
}

function syncUberPayments_(fromTime,toTime) {
  const token=getUberAccessToken_(), url='https://api.uber.com/v1/partners/payments?limit=50&from_time='+fromTime+'&to_time='+toTime, body=uberGetJson_(url,token);
  const rows=(body.payments||[]).map(p=>[new Date(),p.payment_id||'',p.event_time?new Date(p.event_time*1000):'',p.category||'',numberOrZero_(p.amount),p.currency_code||'',p.trip_id||'',numberOrZero_(p.breakdown&&p.breakdown.toll),numberOrZero_(p.breakdown&&p.breakdown.service_fee),numberOrZero_(p.breakdown&&p.breakdown.other)]);
  return appendDedupedRows_(HDO.SHEETS.UBER_PAYMENTS,rows,2);
}

function uberGetJson_(url,token) {
  const response=UrlFetchApp.fetch(url,{headers:{Authorization:'Bearer '+token},muteHttpExceptions:true});
  if(response.getResponseCode()===401&&PropertiesService.getScriptProperties().getProperty('UBER_REFRESH_TOKEN')){
    const refreshed=refreshUberAccessToken_(), retry=UrlFetchApp.fetch(url,{headers:{Authorization:'Bearer '+refreshed},muteHttpExceptions:true});
    if(retry.getResponseCode()>=300)throw new Error('Uber API HTTP '+retry.getResponseCode()+': '+retry.getContentText());
    return JSON.parse(retry.getContentText());
  }
  if(response.getResponseCode()>=300)throw new Error('Uber API HTTP '+response.getResponseCode()+': '+response.getContentText());
  return JSON.parse(response.getContentText());
}

function appendDedupedRows_(sheetName,rows,idColumn) {
  if(!rows.length)return{received:0,appended:0};
  const ss=SpreadsheetApp.openById(HDO.SPREADSHEET_ID),sh=ss.getSheetByName(sheetName),existing=new Set(sh.getLastRow()>1?sh.getRange(2,idColumn,sh.getLastRow()-1,1).getDisplayValues().flat().filter(Boolean):[]),filtered=rows.filter(r=>!existing.has(String(r[idColumn-1]||'')));
  if(filtered.length)sh.getRange(sh.getLastRow()+1,1,filtered.length,filtered[0].length).setValues(filtered);
  return{received:rows.length,appended:filtered.length};
}

function escapeHtml_(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
