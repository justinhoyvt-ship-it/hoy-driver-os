// Pulse Core OS — SetupChecklist.gs

function getPulseCoreSetupChecklist() {
  return {
    project: 'Pulse Core OS',
    attribution: 'A Hoy Creative Project',
    scriptPropertiesToSet: [
      'UBER_SIGNALS_CLIENT_ID',
      'UBER_SIGNALS_CLIENT_SECRET',
      'UBER_SIGNALS_SCOPE (required grant: 3p.signals.eta)',
      'UBER_SIGNALS_TOKEN_URL (sandbox default: https://sandbox-login.uber.com/oauth/v2/token)',
      'UBER_SIGNALS_SANDBOX_URL (exact URL from Uber docs/dashboard)'
    ],
    firstRuns: [
      'pulseV14SelfTest()',
      'runUberSignalsTokenTest()',
      'runUberBearerConnectivityTest() only as an optional scope-isolation diagnostic',
      'testUberSignalsSandbox() only after exact Signals endpoint is confirmed'
    ],
    warning: 'Never put client secrets or access tokens in Sheet cells, GitHub, Wix frontend code, or public JavaScript.'
  };
}

function pulseV14SelfTest() {
  const eventDate = new Date(2026, 6, 11);
  const settings = {
    eventPrebufferMin: 90,
    eventPostbufferMin: 45,
    plannerSwitchDelta: 0.5,
    plannerMinDwellMin: 45
  };
  const morningFactor = eventWindowFactor_(eventDate, '10:00-11:15 PM est.', new Date(2026, 6, 11, 6, 30), settings);
  const insideFactor = eventWindowFactor_(eventDate, '10:00-11:15 PM est.', new Date(2026, 6, 11, 22, 30), settings);
  const base = new Date(2026, 6, 11, 6, 30);
  const topByTime = [];
  for (let i = 0; i < 16; i++) {
    const time = new Date(base.getTime() + i * 15 * 60000);
    const sb = {zone:'South Burlington hotels',score:i<6?13:11.8,confidence:'LOW',reason:'time-of-day prior'};
    const uvm = {zone:'UVM',score:i<6?11:12.5,confidence:'LOW',reason:'time-of-day prior'};
    const scores = [sb, uvm].sort((a,b) => b.score - a.score);
    topByTime.push({time:time,best:scores[0],scores:scores});
  }
  const plan = compressPlan_(topByTime);
  const pass = morningFactor === 0 && insideFactor === 1 && plan.length === 2 && plan[0][2] === 'South Burlington hotels' && plan[1][2] === 'UVM';
  const result = {
    pass: pass,
    eventMorningLeakBlocked: morningFactor === 0,
    eventWindowActive: insideFactor === 1,
    planSegments: plan.map(r => ({zone:r[2], start:r[0], end:r[1]}))
  };
  console.log(JSON.stringify(result));
  return result;
}
